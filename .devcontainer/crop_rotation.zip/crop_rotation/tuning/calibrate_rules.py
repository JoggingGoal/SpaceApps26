"""
STEP 2a of tuning (works with small datasets): calibrate the transparent rule model against real yields.

Fits
  * yield_scale[crop] : how much the starter rules over/under-predict each crop (shrunk toward 1 when data is thin)
  * ndvi_trend_k      : how strongly a field's NDVI trend (% per year) translates to a yield trend

Writes data/calibration.json, which the rule model loads automatically. Delete that file to go back to the
starter values. Prints error before/after so you can see whether it helped.

Usage: python tuning/calibrate_rules.py [--table data/training_table.csv] [--out data/calibration.json]
"""
import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

import config


def rmse(a, b):
    return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", default=str(config.DATA_DIR / "training_table.csv"))
    ap.add_argument("--out", default=str(config.CALIBRATION_FILE))
    ap.add_argument("--min-rows", type=int, default=8, help="minimum rows to calibrate a crop")
    ap.add_argument("--shrink", type=float, default=10.0, help="pseudo-count pulling scales toward 1")
    a = ap.parse_args()
    T = pd.read_csv(a.table)
    ok = T[(T["rule_rel_no_ndvi"] > 0.2) & (T["rel_yield"] > 0)]

    scale = {}
    for crop, g in ok.groupby("crop"):
        if len(g) < a.min_rows:
            print(f"  {crop}: only {len(g)} usable rows, left at 1.0")
            continue
        med = float(np.median(g["rel_yield"] / g["rule_rel_no_ndvi"]))
        n = len(g)
        scale[crop] = float(np.clip(1 + (med - 1) * n / (n + a.shrink), 0.3, 2.0))

    cal = {"yield_scale": scale}
    sc = ok["crop"].map(scale).fillna(1.0)
    base = ok["rule_rel_no_ndvi"] * sc
    has = ok["ndvi_trend_pct"].notna()
    k = config.NDVI_TREND_K
    if has.sum() >= 30:
        x = (ok.loc[has, "ndvi_trend_pct"] / 100.0).to_numpy()          # years_ahead = 1 in the training table
        r = (ok.loc[has, "rel_yield"] / base[has] - 1.0).to_numpy()
        k = float(np.clip((x * r).sum() / max((x * x).sum(), 1e-9), 0.0, 1.5))
        cal["ndvi_trend_k"] = k
        print(f"  NDVI trend coefficient fitted on {int(has.sum())} rows: k = {k:.2f} (starter value {config.NDVI_TREND_K})")
        if k in (0.0, 1.5):
            print("  WARNING: the fit hit its allowed bound (0 or 1.5); NDVI trend may not describe your yields well. Inspect the data.")
    else:
        print(f"  NDVI: only {int(has.sum())} rows with an NDVI trend; keeping the starter coefficient")

    lo, hi = config.NDVI_MULT_CLIP
    nd = np.where(has, np.clip(1 + k * ok["ndvi_trend_pct"].fillna(0) / 100.0, lo, hi), 1.0)
    after = base * nd
    print(f"\nRMSE of relative yield   before: {rmse(ok['rule_rel'], ok['rel_yield']):.3f}   after: {rmse(after, ok['rel_yield']):.3f}"
          f"   ({len(ok)} rows)")
    print("Per-crop scales:", {c: round(v, 2) for c, v in scale.items()})
    print("Note: this is in-sample. For an honest estimate use tuning/train_model.py, which cross-validates by site.")
    cal["meta"] = {"n_rows": int(len(ok)), "created": datetime.now().isoformat(timespec="seconds"), "table": str(a.table)}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(cal, indent=2))
    print(f"Wrote {a.out}")


if __name__ == "__main__":
    main()

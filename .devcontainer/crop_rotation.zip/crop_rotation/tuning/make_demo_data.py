"""
Generates a SYNTHETIC yield + NDVI dataset so you can test the tuning pipeline end to end without real data.
THE NUMBERS ARE FAKE (synthetic climate, invented yields). Never use the output for decisions.
The fake "truth" deliberately differs from the starter rules (crop biases, stronger NDVI effect), so after
running build_training_table -> calibrate_rules / train_model you can see the tuning recover those differences.

Usage: python tuning/make_demo_data.py --out demo --sites 40
Then : python tuning/build_training_table.py --yields demo/yields.csv --ndvi-dir demo/ndvi --offline-demo --out demo/table.csv
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

import climate
import engine
import features
from yield_model import RuleYieldModel

TRUE_BIAS = {"maize": 1.15, "soybean": 0.90, "winter_wheat": 1.05, "oats": 0.95, "sorghum": 1.0,
             "sunflower": 0.85, "field_pea": 1.10}
TRUE_NDVI_K = 0.9


def fake_ndvi(rng, y0, y1, base, trend_pct):
    rows = []
    for y in range(y0 - 6, y1 + 1):
        peak = base * (1 + trend_pct / 100 * (y - y0)) * (1 + rng.normal(0, 0.03))
        for doy in range(1, 366, 16):
            v = 0.15 + (peak - 0.15) * np.exp(-((doy - 200) / 55.0) ** 2) + rng.normal(0, 0.015)
            rows.append((pd.Timestamp(y, 1, 1) + pd.Timedelta(days=doy - 1), float(np.clip(v, 0.05, 0.95))))
    return pd.DataFrame(rows, columns=["date", "ndvi"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="demo")
    ap.add_argument("--sites", type=int, default=40)
    ap.add_argument("--y0", type=int, default=2006)
    ap.add_argument("--y1", type=int, default=2025)
    a = ap.parse_args()
    out = Path(a.out)
    (out / "ndvi").mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(1)
    crops = engine.load_crops()
    key2id = {k: i for i, k in enumerate(crops["crop"])}
    rules = RuleYieldModel(crops, calibration={})
    rows = []
    for s in range(a.sites):
        lat, lon = round(rng.uniform(37, 45), 2), round(rng.uniform(-97, -82), 2)
        site = f"S{s:03d}"
        wx, _ = climate.get_climate(lat, lon, "synthetic", years=a.y1 - a.y0 + 1, end_year=a.y1)
        trend = rng.normal(0.3, 0.6)                                   # true NDVI trend, % per year
        fake_ndvi(rng, a.y0, a.y1, rng.uniform(0.7, 0.85), trend).to_csv(out / "ndvi" / f"{site}.csv", index=False)
        for y in range(a.y0, a.y1 + 1):
            c = rng.choice(list(TRUE_BIAS))
            crop = crops.iloc[key2id[c]]
            f = features.season_features(wx, y, crop, 150 * 1.2, 0.0)
            if not f["valid"]:
                continue
            r = features.assemble(f, key2id[c], 6.5, 3.0, 150 * 1.2)
            rel = rules.predict(pd.DataFrame([{**r, "k": 0}]))[0]
            truth = rel * TRUE_BIAS[c] * (1 + TRUE_NDVI_K * trend / 100) * np.exp(rng.normal(0, 0.08))
            rows.append({"site_id": site, "lat": lat, "lon": lon, "year": y, "crop": c,
                         "yield_t_ha": round(float(truth * crop["base_yield_t_ha"]), 3)})
    pd.DataFrame(rows).to_csv(out / "yields.csv", index=False)
    print(f"SYNTHETIC demo data written to {out}/ ({len(rows)} yield records, {a.sites} sites). "
          f"Hidden truth: crop biases {TRUE_BIAS}, NDVI k = {TRUE_NDVI_K}")


if __name__ == "__main__":
    main()

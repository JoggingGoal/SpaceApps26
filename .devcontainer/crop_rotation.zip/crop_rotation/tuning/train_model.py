"""
STEP 2b of tuning (needs hundreds of yield records): train a gradient-boosting yield model.

Target   : relative yield (observed / crop base yield), so one model covers all crops.
Features : features.ML_FEATURES - stage-aware NASA climate features (GDD, frost, heat at flowering,
           season/flowering rain, water deficit), soil, and NDVI level/trend.
Honest evaluation: GroupKFold by SITE (the model is always tested on fields it never saw) plus a
forward-in-time check (train on early years, test on later years). Compared against the rule model.
The saved model is picked up automatically by the app (models/yield_model.joblib); crops with fewer than
config.ML_MIN_ROWS_PER_CROP training rows fall back to the rules. Delete the file to go back to the rules.

Usage: python tuning/train_model.py [--table data/training_table.csv] [--out models/yield_model.joblib]
"""
import argparse
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import GroupKFold

import config
from features import ML_FEATURES


def rmse(a, b):
    return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))


def make_model():
    return HistGradientBoostingRegressor(
        loss="squared_error", learning_rate=0.05, max_iter=300, max_depth=4, min_samples_leaf=20,
        l2_regularization=1.0, categorical_features=["crop_id"], random_state=config.RANDOM_SEED)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", default=str(config.DATA_DIR / "training_table.csv"))
    ap.add_argument("--out", default=str(config.MODEL_DIR / "yield_model.joblib"))
    a = ap.parse_args()
    T = pd.read_csv(a.table)
    T = T[T["planted"] == 1].reset_index(drop=True)      # crop failure to plant is handled by the simulator
    if len(T) < 100:
        sys.exit(f"Only {len(T)} usable rows. Use tuning/calibrate_rules.py for small datasets (aim for 300+ to train).")
    feats = [f for f in ML_FEATURES if T[f].notna().any()]          # drop features you have no data for (e.g. no soil, no NDVI)
    dropped = sorted(set(ML_FEATURES) - set(feats))
    if dropped:
        print(f"Features with no data in the table (ignored): {dropped}")
    X, y, groups = T[feats], T["rel_yield"].to_numpy(), T["site_id"].astype(str).to_numpy()

    n_splits = int(min(5, T["site_id"].nunique()))
    if n_splits < 3:
        sys.exit("Need at least 3 different sites for spatial cross-validation.")
    oof = np.zeros(len(T))
    for tr, te in GroupKFold(n_splits=n_splits).split(X, y, groups):
        m = make_model().fit(X.iloc[tr], y[tr])
        oof[te] = np.clip(m.predict(X.iloc[te]), 0, 1.3)
    mean_by_crop = T.groupby("crop")["rel_yield"].transform("mean").to_numpy()
    print(f"\nSpatial CV ({n_splits} folds, tested on unseen sites), RMSE of relative yield:")
    print(f"  per-crop average (naive baseline) : {rmse(mean_by_crop, y):.3f}")
    print(f"  rule model (uncalibrated)         : {rmse(T['rule_rel'], y):.3f}")
    print(f"  gradient boosting                 : {rmse(oof, y):.3f}")

    cut = T["year"].quantile(0.7)
    tr, te = T["year"] <= cut, T["year"] > cut
    if te.sum() > 20:
        m = make_model().fit(X[tr], y[tr])
        print(f"Forward in time (train <= {int(cut)}, test later, {int(te.sum())} rows): "
              f"model {rmse(np.clip(m.predict(X[te]), 0, 1.3), y[te]):.3f} vs rules {rmse(T.loc[te, 'rule_rel'], y[te]):.3f}")

    model = make_model().fit(X, y)
    hold = np.random.default_rng(config.RANDOM_SEED).choice(len(T), size=min(len(T), 400), replace=False)
    imp = permutation_importance(model, X.iloc[hold], y[hold], n_repeats=5, random_state=config.RANDOM_SEED)
    order = np.argsort(-imp.importances_mean)
    print("\nWhat the model relies on (permutation importance, in-sample so optimistic):")
    for i in order[:10]:
        print(f"  {feats[i]:22s} {imp.importances_mean[i]:.4f}")

    meta = {"n_rows": int(len(T)), "n_sites": int(T["site_id"].nunique()),
            "rows_per_crop": {str(int(k)): int(v) for k, v in T.groupby("crop_id").size().items()},
            "cv_rmse_model": rmse(oof, y), "cv_rmse_rules": rmse(T["rule_rel"], y), "cv_rmse_naive": rmse(mean_by_crop, y),
            "created": datetime.now().isoformat(timespec="seconds")}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "features": feats, "meta": meta}, a.out)
    print(f"\nSaved {a.out}")
    if meta["cv_rmse_model"] >= meta["cv_rmse_rules"]:
        print("WARNING: the ML model is not beating the rules on unseen sites. Collect more data, or delete the model "
              "file and use calibrate_rules.py instead.")


if __name__ == "__main__":
    main()

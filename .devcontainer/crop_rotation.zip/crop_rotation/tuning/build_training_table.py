"""
STEP 1 of tuning: join your real yield records with NASA climate (and NDVI) features.

Input  : a yields CSV with columns
           site_id, lat, lon, year, crop, yield_t_ha
         optional columns: irrigation_mm, awc_mm, ph, om_pct
         (crop = keys from data/crops.csv, e.g. maize, soybean, winter_wheat)
Sources of yields: USDA NASS county yields, FAOSTAT / national statistics, yield-monitor exports,
                   long-term rotation trials, your own field records.
NDVI   : optional. Put one file per site in --ndvi-dir named <site_id>.csv (columns date,ndvi; NASA AppEEARS
         exports work), or pass --fetch-ndvi to download MODIS NDVI from NASA's ORNL DAAC (slow, cached).
Output : data/training_table.csv  (one row per site-year-crop with all features + observed relative yield)

NDVI features use ONLY seasons before the yield year (what a planner would have known), so there is no leakage.

Usage:
  python tuning/build_training_table.py --yields data/my_yields.csv --ndvi-dir data/ndvi
  python tuning/build_training_table.py --yields demo/yields.csv --ndvi-dir demo/ndvi --offline-demo --out demo/table.csv
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

import climate
import config
import engine
import features
import ndvi as ndvi_mod
from yield_model import RuleYieldModel

REQUIRED = ["site_id", "lat", "lon", "year", "crop", "yield_t_ha"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yields", required=True)
    ap.add_argument("--ndvi-dir")
    ap.add_argument("--fetch-ndvi", action="store_true")
    ap.add_argument("--offline-demo", action="store_true", help="use synthetic climate (testing only)")
    ap.add_argument("--out", default=str(config.DATA_DIR / "training_table.csv"))
    a = ap.parse_args()

    Y = pd.read_csv(a.yields)
    missing = [c for c in REQUIRED if c not in Y.columns]
    if missing:
        sys.exit(f"{a.yields} is missing columns: {missing}")
    crops = engine.load_crops()
    key2id = {k: i for i, k in enumerate(crops["crop"])}
    unknown = sorted(set(Y["crop"]) - set(key2id))
    if unknown:
        print(f"Skipping unknown crops (add them to data/crops.csv): {unknown}")
        Y = Y[Y["crop"].isin(key2id)]
    source = "synthetic" if a.offline_demo else "nasa"
    rows = []
    sites = list(Y.groupby("site_id"))
    for si, (site, g) in enumerate(sites):
        lat, lon = float(g["lat"].iloc[0]), float(g["lon"].iloc[0])
        y0, y1 = int(g["year"].min()), int(g["year"].max())
        print(f"[{si + 1}/{len(sites)}] site {site} ({lat:.2f}, {lon:.2f}) {y0}-{y1}: {len(g)} records", flush=True)
        try:
            wx, _ = climate.get_climate(lat, lon, source, years=y1 - y0 + 1, end_year=y1)
        except climate.ClimateError as e:
            print(f"   climate failed, skipping site: {e}")
            continue
        nd = None
        if a.ndvi_dir and (Path(a.ndvi_dir) / f"{site}.csv").exists():
            nd = ndvi_mod.load_ndvi_csv(Path(a.ndvi_dir) / f"{site}.csv")
        elif a.fetch_ndvi:
            try:
                nd = ndvi_mod.fetch_ndvi_ornl(lat, lon, max(2001, y0 - 6), y1)
            except Exception as e:
                print(f"   NDVI download failed: {e}")
        for r in g.itertuples(index=False):
            crop = crops.iloc[key2id[r.crop]]
            awc = getattr(r, "awc_mm", np.nan)
            awc = config.SOIL_AWC_MM_PER_M["loam"] * config.ROOTING_DEPTH_M if pd.isna(awc) else float(awc)
            irr = getattr(r, "irrigation_mm", 0.0)
            irr = 0.0 if pd.isna(irr) else float(irr)
            f = features.season_features(wx, int(r.year), crop, awc, irr)
            if not f["valid"]:
                continue
            ns = ndvi_mod.prior_summary(nd, int(r.year), lat)
            ph = getattr(r, "ph", np.nan)
            om = getattr(r, "om_pct", np.nan)
            row = features.assemble(f, key2id[r.crop], np.nan if pd.isna(ph) else float(ph),
                                    np.nan if pd.isna(om) else float(om), awc,
                                    ns["trend_pct_per_year"], ns["mean_peak"] if ns["usable"] else np.nan)
            row.update(site_id=site, year=int(r.year), crop=r.crop, k=0, yield_t_ha=float(r.yield_t_ha),
                       rel_yield=float(r.yield_t_ha) / float(crop["base_yield_t_ha"]))
            rows.append(row)
    T = pd.DataFrame(rows)
    if T.empty:
        sys.exit("No usable rows produced.")
    rules = RuleYieldModel(crops, calibration={})                  # uncalibrated reference
    T["rule_rel"] = rules.predict(T)
    T["rule_rel_no_ndvi"] = rules.predict(T.assign(ndvi_trend_pct=np.nan, ndvi_mean_peak=np.nan))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    T.to_csv(a.out, index=False)
    print(f"\nWrote {a.out}: {len(T)} rows, {T['site_id'].nunique()} sites, "
          f"{T['ndvi_trend_pct'].notna().mean() * 100:.0f}% of rows with NDVI trend")
    print(T.groupby("crop").size().rename("rows").to_string())
    print("\nNext: python tuning/calibrate_rules.py   (few records)   or   python tuning/train_model.py   (hundreds+ records)")


if __name__ == "__main__":
    main()
